//the js file validating fields in the registration form
//declaring and defining validation function
const validation = () => {
  //assignment of variables
  const identification = document.getElementById("userid").value;
  const password = document.getElementById("pass").value;
  const pwd = /^\s{7,12}$/;
  const usr = /^\d{5,12}$/;
  const Name = document.getElementById("username").value;
  const zCode = document.getElementById("code").value;
  const Address = document.getElementById("address").value;
  const email = document.getElementById("Email").value;
  const country = document.getElementById("ctr").value;
  const sex = document.getElementsByName("gender");
  const gender1 = document.getElementById("gender2");
  const language = document.getElementsByName("lang");
  const languageText = document.getElementById("langbtn");
  const About = document.getElementById("aboutus").value;

  //validating the id field

  /*checking if the id value is not a number or it matches with 
   the usr variable or it is null and if yes, it shows an error*/
  if (
    isNaN(identification) ||
    !identification.match(usr) ||
    identification == null
  ) {
    userid.style.border = "1px solid red";
    console.log("required, user id must be of length 5-12!");
  } else {
    userid.style.border = "1px solid green";
  }

  //validation of the password

  //if the password field is empty, it displays an error
  if (password != "") {
    //if the password is greater or equal to 7 and lessthan or egual to 12, shows a green border otherwise an error is encountered
    if (password.length >= 7 && password.length <= 12) {
      pass.style.border = "1px solid green";
    } else {
      pass.style.border = "1px solid red";
      console.log("please the password must be of length 7-12!");
    }
  } else {
    pass.style.border = "1px solid red";
    console.log("please enter the password");
  }

  //validation of the name field
  //if the name field is empty, it displays an error
  if (Name != "") {
    /*if the name value is a string, not a number or an instance of a string then a green border
    border will be shown otherwise an error is encountered*/
    if ((typeof Name == "string" && isNaN(Name)) || Name instanceof String) {
      username.style.border = "1px solid green";
    } else {
      username.style.border = "1px solid red";
      console.log("please insert only characters");
    }
  } else {
    username.style.border = "1px solid red";
    console.log("please insert your name!");
  }
  //validating the address field
  if (typeof Address == "string") {
    address.style.border = "1px solid green";
  }

  //validating the zip field
  //checking if zip field has nothing entered if true a red border indicating an error is displayed
  if (zCode != "") {
    //if the zip code value is not a number or it's an instance of a string then an error is shown.
    if (isNaN(zCode) || zCode instanceof String) {
      code.style.border = "1px solid red";
      console.log("please insert only numeric values!");
    } else {
      code.style.border = "1px solid green";
    }
  } else {
    code.style.border = "1px solid red";
    console.log("please insert your zip code!");
  }

  //validation of the email
  //checking if email field has nothing entered if true a red border indicating an error is displayed
  if (email != "") {
    /*if the email value includes . and @ then a green border meaning 
    success is displayed otherwise a redborder implying an error is displayed.*/

    if (email.includes(".") && email.includes("@")) {
      Email.style.border = "1px solid green";
    } else {
      Email.style.border = "1px solid red";
      console.log("please insert your valid email!");
    }
  } else {
    Email.style.border = "1px solid red";
    console.log("please insert your email!");
  }
  //validating the country field
  //checking if country field has nothing selected if yes it a red border is shown
  if (country == "") {
    ctr.style.border = "1px solid red";
    console.log("please select a country!");
  } else {
    ctr.style.border = "1px solid green";
  }

  //validating gender
  let a = 0;
  //looping through the radio buttons to check if no button is selected
  for (let i = 0; i < sex.length; i++) {
    if (sex.item(i).checked == false) {
      a++;
    }
  }
  /*if the number of unselected buttons  is equal to the length of
   radio buttons then none of the buttons has been selected*/
  if (a == sex.length) {
    gender1.type = "text";
    gender1.value = "choose sex";
    gender1.style.color = "red";
  }

  //validation of language
  let b = 0;
  //looping through to check if no checkbox has been selected
  for (let c = 0; c < language.length; c++) {
    if (language.item(c).checked == false) {
      b++;
    } else {
    }
  }
  /*if the number of unselected is equal to the length of checkboxes
   then no checkbox has been selected*/

  if (b == language.length) {
    languageText.type = "text";
    languageText.value = "choose language";
    languageText.style.color = "red";
  }

  //validating the about field
  if (typeof About == "string") {
    aboutus.style.border = "1px solid green";
  }
};
